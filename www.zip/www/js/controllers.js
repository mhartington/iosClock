angular.module('starter.controllers', [])

    .controller('WorldClockCtrl', function ($scope) {
    })

    .controller('AlarmCtrl', function ($scope, $ionicModal) {
        $scope.data = {
            showDelete: false
        };



        $ionicModal.fromTemplateUrl('templates/alarm-modal.html', function(modal) {
            $scope.modal = modal;
        }, {
            animation: 'slide-in-up',
            focusFirstInput: true
        });



    })

    .controller('TimerCtrl', function ($scope) {

    })

    .controller('StopWatchCtrl', function ($scope) {
    });
